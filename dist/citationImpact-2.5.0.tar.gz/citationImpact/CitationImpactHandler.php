<?php

/**
 * @file plugins/generic/citationImpact/CitationImpactHandler.php
 *
 * Distributed under the GNU GPL v3.
 *
 * @class CitationImpactHandler
 * @brief Public "Citation Impact" page and its JSON data.
 */

namespace APP\plugins\generic\citationImpact;

use APP\core\Application;
use APP\handler\Handler;
use APP\plugins\generic\citationImpact\classes\CitationImpactPalette;
use APP\plugins\generic\citationImpact\classes\CitationImpactService;
use APP\template\TemplateManager;
use PKP\facades\Locale;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Throwable;

class CitationImpactHandler extends Handler {

	const VERSION = '2.5.0';

	/** Steps of the ordinal ramp, --ci-r0 (weak) … --ci-r8 (strong). */
	const RAMP_STEPS = 9;

	/** @var CitationImpactPlugin */
	protected $plugin;

	public function __construct(CitationImpactPlugin $plugin) {
		parent::__construct();
		$this->plugin = $plugin;
	}

	/**
	 * The public page, rendered inside the journal theme.
	 */
	public function index($args, $request) {
		$context = $request->getContext();
		if (!$context) {
			throw new NotFoundHttpException();
		}
		$this->setupTemplate($request);
		$plugin = $this->plugin;

		$locale = Locale::getLocale();
		$service = new CitationImpactService($context->getId());
		try {
			$data = $service->build($locale);
		} catch (Throwable $e) {
			error_log('Citation Impact: ' . $e->getMessage());
			list($wf, $wt) = CitationImpactService::windowYears(true);
			$data = array(
				'stats' => array('articles' => 0, 'checked' => 0, 'citedArticles' => 0, 'totalCitations' => 0, 'recentCitations' => 0,
					'hIndex' => 0, 'i10Index' => 0, 'windowFrom' => $wf, 'windowTo' => $wt, 'windowCitations' => 0, 'windowArticles' => 0,
					'windowCitedArticles' => 0, 'windowHIndex' => 0, 'windowI10Index' => 0, 'maxCitations' => 0),
				'distribution' => array(), 'byYear' => array(), 'rows' => array(), 'updatedAt' => null, 'license' => null, 'withoutDoi' => 0,
				'sources' => $service->sources(), 'pending' => true, 'separate' => $service->isSeparate(), 'openAlex' => null,
				'byIssue' => array(), 'selfCitations' => array('citing' => 0, 'self' => 0), 'history' => array(),
			);
		}
		$separate = !empty($data['separate']) && in_array('openalex', $data['sources'], true);
		$dispatcher = $request->getDispatcher();
		$etAl = __('plugins.generic.citationImpact.etAl');

		$rows = array();
		foreach ($data['rows'] as $r) {
			$authors = $r['authors'];
			$authorText = count($authors) > 3 ? implode(', ', array_slice($authors, 0, 3)) . ' ' . $etAl : implode(', ', $authors);
			$rows[] = array(
				'd' => $r['doi'],
				't' => $r['title'] !== '' ? $r['title'] : $r['doi'],
				'a' => $authorText,
				'y' => $r['year'],
				'dt' => $r['date'],
				'u' => $dispatcher->url($request, Application::ROUTE_PAGE, null, 'article', 'view', array((string) ($r['urlPath'] ? $r['urlPath'] : $r['submissionId']))),
				'c' => $r['cites'],
				'r' => $r['recent'],
				'f' => $r['fcr'],
				'cd' => $r['citesDimensions'],
				'co' => $r['citesOpenAlex'],
				'oi' => $r['openAlexId'],
				'ro' => $r['recentOpenAlex'],
				'is' => $r['issue'],
				'sc' => $r['selfCites'],
				'cw' => array_map(function ($w) {
					return array('t' => $w['t'], 'y' => $w['y'], 'd' => $w['d'], 'a' => $w['a'], 's' => $w['s'], 'id' => $w['id'], 'self' => (bool) $w['self']);
				}, $r['citing']),
			);
		}

		$numberLocale = strpos($locale, 'id') === 0 ? 'id' : 'en';
		$fmt = function ($n, $dec = 0) use ($numberLocale) {
			return $numberLocale === 'id' ? number_format((float) $n, $dec, ',', '.') : number_format((float) $n, $dec, '.', ',');
		};
		$s = $data['stats'];
		$perPage = 25;
		$citedPct = $s['checked'] ? round($s['citedArticles'] / $s['checked'] * 100) : 0;
		$winCitedPct = $s['windowArticles'] ? round($s['windowCitedArticles'] / $s['windowArticles'] * 100) : 0;

		// Top three (only articles with at least one citation).
		$top = array();
		foreach (array_slice($rows, 0, 3) as $i => $r) {
			if (!$r['c']) {
				break;
			}
			$top[] = array_merge($r, array(
				'rank' => $i + 1,
				'cF' => $fmt($r['c']),
				'fF' => $r['f'] === null ? null : $fmt($r['f'], 1),
				'fHigh' => $r['f'] !== null && $r['f'] >= 1,
			));
		}

		$templateMgr = TemplateManager::getManager($request);

		// Colours: plugin setting → active theme's colour option → detected in
		// the browser from the rendered theme (js/impact.js) → fallback blue.
		$settings = CitationImpactService::getSettings($context->getId());
		$accent = CitationImpactPalette::normalizeHex($settings['accentColor']);
		$accentSource = 'custom';
		$accentFallback = null;
		if ($accent === null) {
			$accent = CitationImpactPalette::themeColour(CitationImpactPalette::getActiveTheme($context));
			$accentSource = 'theme';
			// A black/grey theme colour (e.g. a dark header) makes every bar and
			// highlight grey; let the browser take the theme's link colour first
			// and keep the theme colour as the fallback.
			if ($accent !== null && !CitationImpactPalette::isColourful($accent)) {
				$accentFallback = $accent;
				$accent = null;
			}
		}
		if ($accent === null) {
			$accentSource = 'auto';
		}
		$templateMgr->assign(array(
			'ciAccent' => $accent,
			'ciAccentSource' => $accentSource,
			'ciAccentFallback' => $accentFallback,
			'ciPaletteStyle' => CitationImpactPalette::style(CitationImpactPalette::accentVars($accent ?: ($accentFallback ?: CitationImpactPalette::FALLBACK))),
		));

		$base = $request->getBaseUrl() . '/' . $plugin->getPluginPath();
		$templateMgr->addStyleSheet('citationImpact', $base . '/css/impact.css?v=' . self::VERSION, array('contexts' => 'frontend'));
		$templateMgr->addJavaScript('citationImpact', $base . '/js/impact.js?v=' . self::VERSION, array('contexts' => 'frontend'));
		$templateMgr->assign(array(
			'ciStats' => array(
				'articles' => $fmt($s['articles']),
				'checked' => $fmt($s['checked']),
				'citedArticles' => $fmt($s['citedArticles']),
				'citedPct' => $citedPct,
				'mean' => $fmt($s['checked'] ? $s['totalCitations'] / $s['checked'] : 0, 1),
				'max' => $fmt($s['maxCitations']),
				'totalCitations' => $fmt($s['totalCitations']),
				'recentCitations' => $fmt($s['recentCitations']),
				'hIndex' => (int) $s['hIndex'],
				'i10Index' => (int) $s['i10Index'],
				'windowCitations' => $fmt($s['windowCitations']),
				'windowArticles' => $fmt($s['windowArticles']),
				'windowCitedArticles' => $fmt($s['windowCitedArticles']),
				'windowCitedPct' => $winCitedPct,
				'windowHIndex' => (int) $s['windowHIndex'],
				'windowI10Index' => (int) $s['windowI10Index'],
				'windowFrom' => (int) $s['windowFrom'],
				'windowTo' => (int) $s['windowTo'],
			),
			'ciRing' => self::ring($citedPct),
			'ciRingWindow' => self::ring($winCitedPct),
			'ciHasData' => $s['checked'] > 0,
			'ciPending' => $data['pending'],
			'ciUpdatedAt' => $data['updatedAt'],
			'ciLicense' => in_array('dimensions', $data['sources'], true) ? $data['license'] : null,
			// "Separate" mode: the page is about Dimensions; OpenAlex has its own card and column.
			'ciSources' => self::sourcesLabel($separate ? array('dimensions') : $data['sources'], false),
			'ciSourcesHtml' => self::sourcesLabel($separate ? array('dimensions') : $data['sources'], true),
			'ciMerged' => !$separate && count($data['sources']) > 1,
			'ciSeparate' => $separate,
			'ciOa' => $data['openAlex'] ? array(
				'totalCitations' => $fmt($data['openAlex']['totalCitations']),
				'recentCitations' => $fmt($data['openAlex']['recentCitations']),
				'windowCitations' => $fmt($data['openAlex']['windowCitations']),
				'citedArticles' => $fmt($data['openAlex']['citedArticles']),
				'checked' => $fmt($data['openAlex']['checked']),
				'hIndex' => (int) $data['openAlex']['hIndex'],
				'windowHIndex' => (int) $data['openAlex']['windowHIndex'],
			) : null,
			'ciHasDim' => in_array('dimensions', $data['sources'], true),
			'ciCsvUrl' => $dispatcher->url($request, Application::ROUTE_PAGE, null, $plugin->getPagePath($context->getId()), 'csv'),
			'ciWithoutDoi' => $data['withoutDoi'] ? $fmt($data['withoutDoi']) : null,
			'ciListMode' => $settings['listMode'],
			'ciByYear' => array_reverse(array_map(function ($y) use ($fmt) {
				return array('year' => $y['year'], 'articles' => $fmt($y['articles']), 'citations' => $fmt($y['citations']));
			}, $data['byYear'])),
			'ciChartWide' => self::yearChart($data['byYear'], $fmt, 720, 'wide'),
			'ciChartNarrow' => self::yearChart($data['byYear'], $fmt, 360, 'narrow'),
			'ciByIssue' => array_map(function ($v) use ($fmt) {
				return array(
					'label' => $v['label'],
					'articles' => $fmt($v['articles']),
					'cited' => $fmt($v['cited']),
					'citedPct' => $v['checked'] ? round($v['cited'] / $v['checked'] * 100) : 0,
					'citations' => $fmt($v['citations']),
					'openAlex' => $fmt($v['openAlex']),
				);
			}, $data['byIssue']),
			'ciSelf' => $data['selfCitations']['citing'] ? array(
				'self' => $fmt($data['selfCitations']['self']),
				'citing' => $fmt($data['selfCitations']['citing']),
				'pct' => round($data['selfCitations']['self'] / $data['selfCitations']['citing'] * 100),
			) : null,
			'ciHistoryWide' => self::historyChart($data['history'], $fmt, 720, $separate),
			'ciHistoryNarrow' => self::historyChart($data['history'], $fmt, 360, $separate),
			'ciHistoryPoints' => count($data['history']),
			'ciHistoryTable' => array_reverse(array_map(function ($month, $h) use ($fmt) {
				return array('month' => self::monthLabel($month), 'c' => $fmt($h['c']), 'w' => $fmt($h['w']), 'wf' => $h['wf'], 'wt' => $h['wt'], 'o' => $fmt($h['o']));
			}, array_keys($data['history']), array_values($data['history']))),
			'ciCitingCsvUrl' => $dispatcher->url($request, Application::ROUTE_PAGE, null, $plugin->getPagePath($context->getId()), 'citing'),
			'ciHasOpenAlex' => in_array('openalex', $data['sources'], true),
			'ciYearFrom' => $data['byYear'] ? $data['byYear'][0]['year'] : null,
			'ciYearTo' => $data['byYear'] ? $data['byYear'][count($data['byYear']) - 1]['year'] : null,
			'ciDistribution' => self::distribution($data['distribution'], $s['checked'], $fmt),
			'ciTop' => $top,
			'ciRowCount' => count($rows),
			'ciShown' => __('plugins.generic.citationImpact.shown', array('shown' => $fmt(min($perPage, count($rows))), 'total' => $fmt(count($rows)))),
			'ciJson' => json_encode(array(
				'rows' => $rows,
				'perPage' => $perPage,
				'max' => (int) $s['maxCitations'],
				'locale' => $numberLocale,
				'window' => array((int) $s['windowFrom'], (int) $s['windowTo']),
				'dim' => in_array('dimensions', $data['sources'], true),
				'merged' => !$separate && count($data['sources']) > 1,
				'separate' => $separate,
				'i18n' => array(
					'shown' => __('plugins.generic.citationImpact.shown'),
					'details' => __('plugins.generic.citationImpact.dimensionsDetails'),
					'openalex' => __('plugins.generic.citationImpact.openAlexDetails'),
					'dimN' => __('plugins.generic.citationImpact.sourceCount', array('source' => 'Dimensions')),
					'oaN' => __('plugins.generic.citationImpact.sourceCount', array('source' => 'OpenAlex')),
					'citingN' => __('plugins.generic.citationImpact.citing.summary'),
					'self' => __('plugins.generic.citationImpact.citing.self'),
					'selfN' => __('plugins.generic.citationImpact.citing.selfN'),
					'issue' => __('plugins.generic.citationImpact.col.issue'),
					'fcrTimes' => __('plugins.generic.citationImpact.fcrTimes'),
				),
			), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE),
		));
		// Preformat the first page of rows (no-JS fallback).
		$first = array();
		$max = max(1, (int) $s['maxCitations']);
		foreach (array_slice($rows, 0, $perPage) as $i => $r) {
			$r['rank'] = $i + 1;
			$r['cF'] = $r['c'] === null ? null : $fmt($r['c']);
			$r['cW'] = !$r['c'] ? 0 : round(max(2, $r['c'] / $max * 100), 1);
			$r['rF'] = $r['r'] === null ? null : $fmt($r['r']);
			$r['fF'] = $r['f'] === null ? null : $fmt($r['f'], 1);
			$r['fHigh'] = $r['f'] !== null && $r['f'] >= 1;
			$first[] = $r;
		}
		$templateMgr->assign('ciRows', $first);

		header('X-LiteSpeed-Cache-Control: no-cache');
		return $templateMgr->display($plugin->getTemplateResource('impact.tpl'));
	}

	/**
	 * Machine-readable data: /{journal}/{pagePath}/json
	 */
	public function json($args, $request) {
		$context = $request->getContext();
		if (!$context) {
			throw new NotFoundHttpException();
		}
		$service = new CitationImpactService($context->getId());
		$data = $service->build(Locale::getLocale());
		$dispatcher = $request->getDispatcher();
		$articles = array();
		foreach ($data['rows'] as $r) {
			$articles[] = array(
				'doi' => $r['doi'],
				'title' => $r['title'],
				'authors' => $r['authors'],
				'date' => $r['date'],
				'url' => $dispatcher->url($request, Application::ROUTE_PAGE, null, 'article', 'view', array((string) ($r['urlPath'] ? $r['urlPath'] : $r['submissionId']))),
				'times_cited' => $r['cites'],
				'times_cited_dimensions' => $r['citesDimensions'],
				'times_cited_openalex' => $r['citesOpenAlex'],
				'openalex_id' => $r['openAlexId'],
				'recent_citations' => $r['recent'],
				'recent_citations_openalex' => $r['recentOpenAlex'],
				'field_citation_ratio' => $r['fcr'],
			);
		}
		header('Content-Type: application/json; charset=utf-8');
		header('Access-Control-Allow-Origin: *');
		header('Cache-Control: no-cache');
		echo json_encode(array(
			'journal' => $context->getLocalizedName(),
			'source' => self::sourcesLabel($data['sources'], false),
			'sources' => array_map(function ($s) {
				return $s === 'openalex' ? 'OpenAlex (https://openalex.org)' : 'Dimensions (https://www.dimensions.ai)';
			}, $data['sources']),
			'times_cited_rule' => !empty($data['separate']) ? 'Dimensions only; OpenAlex reported separately'
				: (count($data['sources']) > 1 ? 'highest of the sources, per article' : 'single source'),
			'openalex_summary' => $data['openAlex'],
			'license' => in_array('dimensions', $data['sources'], true) ? $data['license'] : null,
			'updated_at' => $data['updatedAt'] ? date('c', $data['updatedAt']) : null,
			'stats' => $data['stats'],
			'by_year' => $data['byYear'],
			'distribution' => $data['distribution'],
			'articles' => $articles,
		), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_INVALID_UTF8_SUBSTITUTE);
		exit;
	}

	/**
	 * Spreadsheet of every article, for accreditation evidence:
	 * /{journal}/{pagePath}/csv[?sep=comma|semicolon]
	 *
	 * Opens directly in Excel: UTF-8 with BOM, ";" and decimal comma for
	 * Indonesian, "," and decimal point otherwise.
	 */
	public function csv($args, $request) {
		$context = $request->getContext();
		if (!$context) {
			throw new NotFoundHttpException();
		}
		$locale = Locale::getLocale();
		$sep = (string) $request->getUserVar('sep');
		$sep = $sep === 'comma' ? ',' : ($sep === 'semicolon' ? ';' : (strpos($locale, 'id') === 0 ? ';' : ','));
		$dec = $sep === ';' ? ',' : '.';

		$service = new CitationImpactService($context->getId());
		$data = $service->build($locale, true);
		$dimensions = in_array('dimensions', $data['sources'], true);
		$openAlex = in_array('openalex', $data['sources'], true);
		// Separate mode: Dimensions columns are the main ones, OpenAlex has its own; no combined column.
		$separate = !empty($data['separate']) && $dimensions && $openAlex;
		$s = $data['stats'];
		$dispatcher = $request->getDispatcher();
		$yes = __('plugins.generic.citationImpact.csv.yes');
		$no = __('plugins.generic.citationImpact.csv.no');
		$num = function ($v, $d = 0) use ($dec) {
			return $v === null ? '' : number_format((float) $v, $d, $dec, '');
		};

		$head = array(
			__('plugins.generic.citationImpact.csv.rank'),
			__('plugins.generic.citationImpact.csv.title'),
			__('plugins.generic.citationImpact.csv.authors'),
			__('plugins.generic.citationImpact.col.year'),
			__('plugins.generic.citationImpact.csv.date'),
			__('plugins.generic.citationImpact.col.issue'),
			'DOI',
			__('plugins.generic.citationImpact.csv.url'),
		);
		if ($separate) {
			$head[] = __('plugins.generic.citationImpact.csv.citesSource', array('source' => 'Dimensions'));
			$head[] = __('plugins.generic.citationImpact.stat.recent') . ' (Dimensions)';
			$head[] = 'FCR (Dimensions)';
			$head[] = __('plugins.generic.citationImpact.csv.citesSource', array('source' => 'OpenAlex'));
			$head[] = __('plugins.generic.citationImpact.stat.recent') . ' (OpenAlex)';
		} else {
			$head[] = __('plugins.generic.citationImpact.csv.cites');
			if ($dimensions && $openAlex) {
				$head[] = __('plugins.generic.citationImpact.csv.citesSource', array('source' => 'Dimensions'));
				$head[] = __('plugins.generic.citationImpact.csv.citesSource', array('source' => 'OpenAlex'));
			}
			$head[] = __('plugins.generic.citationImpact.stat.recent');
			if ($dimensions) {
				$head[] = 'FCR (Dimensions)';
			}
		}
		$head[] = __('plugins.generic.citationImpact.csv.window', array('from' => $s['windowFrom'], 'to' => $s['windowTo']));
		if ($dimensions) {
			$head[] = __('plugins.generic.citationImpact.csv.link', array('source' => 'Dimensions'));
		}
		if ($openAlex) {
			$head[] = __('plugins.generic.citationImpact.csv.citingFound');
			$head[] = __('plugins.generic.citationImpact.csv.selfCites');
			$head[] = __('plugins.generic.citationImpact.csv.link', array('source' => 'OpenAlex'));
		}

		$filename = 'citation-impact-' . preg_replace('/[^a-z0-9_-]+/i', '-', $context->getPath()) . '-' . date('Y-m-d') . '.csv';
		header('Content-Type: text/csv; charset=utf-8');
		header('Content-Disposition: attachment; filename="' . $filename . '"');
		header('Cache-Control: no-cache');
		header('X-LiteSpeed-Cache-Control: no-cache');
		$out = fopen('php://output', 'w');
		fwrite($out, "\xEF\xBB\xBF");
		$put = function (array $row) use ($out, $sep) {
			// Neutralise spreadsheet formulas in text taken from the database.
			fputcsv($out, array_map(function ($v) {
				$v = (string) $v;
				return preg_match('/^[=+\-@\t\r]/', $v) ? "'" . $v : $v;
			}, $row), $sep, '"', '');
		};
		$put($head);
		foreach ($data['rows'] as $i => $r) {
			$row = array(
				$i + 1,
				$r['title'] !== '' ? $r['title'] : $r['doi'],
				implode('; ', $r['authors']),
				$r['year'],
				$r['date'],
				(string) $r['issue'],
				$r['doi'],
				$dispatcher->url($request, Application::ROUTE_PAGE, null, 'article', 'view', array((string) ($r['urlPath'] ? $r['urlPath'] : $r['submissionId']))),
			);
			if ($separate) {
				$row[] = $num($r['citesDimensions']);
				$row[] = $num($r['recent']);
				$row[] = $num($r['fcr'], 2);
				$row[] = $num($r['citesOpenAlex']);
				$row[] = $num($r['recentOpenAlex']);
			} else {
				$row[] = $num($r['cites']);
				if ($dimensions && $openAlex) {
					$row[] = $num($r['citesDimensions']);
					$row[] = $num($r['citesOpenAlex']);
				}
				$row[] = $num($r['recent']);
				if ($dimensions) {
					$row[] = $num($r['fcr'], 2);
				}
			}
			$row[] = $r['inWindow'] ? $yes : $no;
			if ($dimensions) {
				$row[] = 'https://badge.dimensions.ai/details/doi/' . $r['doi'];
			}
			if ($openAlex) {
				$row[] = $num(count($r['citing']));
				$row[] = $num($r['selfCites']);
				$row[] = $r['openAlexId'] ? 'https://openalex.org/works?filter=cites:' . $r['openAlexId'] : '';
			}
			$put($row);
		}
		fclose($out);
		exit;
	}

	/**
	 * Every citing work found in OpenAlex, one row per (article, citing work),
	 * with a self-citation flag: /{journal}/{pagePath}/citing
	 */
	public function citing($args, $request) {
		$context = $request->getContext();
		if (!$context) {
			throw new NotFoundHttpException();
		}
		$locale = Locale::getLocale();
		$sep = (string) $request->getUserVar('sep');
		$sep = $sep === 'comma' ? ',' : ($sep === 'semicolon' ? ';' : (strpos($locale, 'id') === 0 ? ';' : ','));
		$service = new CitationImpactService($context->getId());
		$data = $service->build($locale, true);
		$yes = __('plugins.generic.citationImpact.csv.yes');
		$no = __('plugins.generic.citationImpact.csv.no');
		$out = self::csvStart('citing-works-' . preg_replace('/[^a-z0-9_-]+/i', '-', $context->getPath()) . '-' . date('Y-m-d') . '.csv');
		self::csvRow($out, $sep, array(
			__('plugins.generic.citationImpact.csv.rank'),
			__('plugins.generic.citationImpact.csv.citedTitle'),
			__('plugins.generic.citationImpact.csv.citedDoi'),
			__('plugins.generic.citationImpact.csv.citingTitle'),
			__('plugins.generic.citationImpact.csv.citingAuthors'),
			__('plugins.generic.citationImpact.csv.citingSource'),
			__('plugins.generic.citationImpact.col.year'),
			__('plugins.generic.citationImpact.csv.citingDoi'),
			__('plugins.generic.citationImpact.citing.self'),
			'OpenAlex',
		));
		$n = 0;
		foreach ($data['rows'] as $r) {
			foreach ($r['citing'] as $w) {
				self::csvRow($out, $sep, array(
					++$n,
					$r['title'] !== '' ? $r['title'] : $r['doi'],
					$r['doi'],
					$w['t'],
					$w['a'],
					$w['s'],
					$w['y'],
					$w['d'] ? 'https://doi.org/' . $w['d'] : '',
					$w['self'] ? $yes : $no,
					$w['id'] ? 'https://openalex.org/' . $w['id'] : '',
				));
			}
		}
		fclose($out);
		exit;
	}

	/**
	 * Send CSV headers and the UTF-8 BOM; return the output stream.
	 */
	protected static function csvStart($filename) {
		header('Content-Type: text/csv; charset=utf-8');
		header('Content-Disposition: attachment; filename="' . $filename . '"');
		header('Cache-Control: no-cache');
		header('X-LiteSpeed-Cache-Control: no-cache');
		$out = fopen('php://output', 'w');
		fwrite($out, "\xEF\xBB\xBF");
		return $out;
	}

	/**
	 * One CSV row; text that a spreadsheet would run as a formula is neutralised.
	 */
	protected static function csvRow($out, $sep, array $row) {
		fputcsv($out, array_map(function ($v) {
			$v = (string) $v;
			return preg_match('/^[=+\-@\t\r]/', $v) ? "'" . $v : $v;
		}, $row), $sep, '"', '');
	}

	/**
	 * "Nov 2026" in the page language.
	 */
	protected static function monthLabel($ym) {
		list($y, $m) = array_map('intval', explode('-', $ym));
		$names = explode(',', __('plugins.generic.citationImpact.months'));
		return (isset($names[$m - 1]) ? trim($names[$m - 1]) : $m) . ' ' . $y;
	}

	/**
	 * Monthly totals as a line chart: the main count (solid, accent) and, in
	 * separate mode, OpenAlex (dashed, neutral). Needs two months of data.
	 * @return string SVG, or '' with fewer than two points
	 */
	protected static function historyChart(array $history, $fmt, $W, $separate) {
		if (count($history) < 2) {
			return '';
		}
		$narrow = $W < 500;
		$H = $narrow ? 200 : 240;
		$L = 44; $R = 16; $T = 20; $B = 28;
		$pw = $W - $L - $R;
		$ph = $H - $T - $B;
		$months = array_keys($history);
		$n = count($months);
		$maxV = 1;
		foreach ($history as $h) {
			$maxV = max($maxV, (int) $h['c'], $separate ? (int) $h['o'] : 0);
		}
		$max = self::niceMax($maxV);
		$x = function ($i) use ($L, $pw, $n) {
			return round($L + ($n === 1 ? $pw / 2 : $pw * $i / ($n - 1)), 1);
		};
		$y = function ($v) use ($T, $ph, $max) {
			return round($T + $ph - $ph * $v / $max, 1);
		};
		$esc = array(__CLASS__, 'esc');
		$svg = '<svg class="ci-chart ci-chart-' . ($narrow ? 'narrow' : 'wide') . '" viewBox="0 0 ' . $W . ' ' . $H . '" role="img" aria-label="' . $esc(__('plugins.generic.citationImpact.history')) . '">';
		for ($i = 0; $i <= 4; $i++) {
			$yy = round($T + $ph - $ph * $i / 4, 1);
			$svg .= '<line class="ci-grid' . ($i === 0 ? ' ci-base' : '') . '" x1="' . $L . '" x2="' . ($W - $R) . '" y1="' . $yy . '" y2="' . $yy . '"/>';
			$svg .= '<text class="ci-tick" x="' . ($L - 8) . '" y="' . ($yy + 4) . '" text-anchor="end">' . $esc($fmt($max * $i / 4)) . '</text>';
		}
		$series = array(array('c', 'ci-line'));
		if ($separate) {
			array_unshift($series, array('o', 'ci-line ci-line-oa'));
		}
		foreach ($series as $sr) {
			$pts = array();
			foreach ($months as $i => $mo) {
				$pts[] = $x($i) . ',' . $y((int) $history[$mo][$sr[0]]);
			}
			$svg .= '<polyline class="' . $sr[1] . '" fill="none" points="' . implode(' ', $pts) . '"/>';
		}
		$every = (int) ceil($n / ($narrow ? 4 : 8));
		foreach ($months as $i => $mo) {
			$h = $history[$mo];
			$tip = self::monthLabel($mo) . ' · ' . $fmt($h['c']) . ' ' . __('plugins.generic.citationImpact.chart.citations')
				. ($separate ? ' · OpenAlex ' . $fmt($h['o']) : '');
			$svg .= '<g class="ci-bar" tabindex="0" data-tip="' . $esc($tip) . '"><title>' . $esc($tip) . '</title>'
				. '<rect class="ci-hit" x="' . round($x($i) - $pw / max(1, $n - 1) / 2, 1) . '" y="' . $T . '" width="' . round($pw / max(1, $n - 1), 1) . '" height="' . $ph . '"/>'
				. '<circle class="ci-dot ci-mark" cx="' . $x($i) . '" cy="' . $y((int) $h['c']) . '" r="3.5"/></g>';
			if (($n - 1 - $i) % $every === 0) {
				$svg .= '<text class="ci-tick" x="' . $x($i) . '" y="' . ($H - 8) . '" text-anchor="middle">' . $esc(self::monthLabel($mo)) . '</text>';
			}
		}
		$last = $history[$months[$n - 1]];
		$svg .= '<text class="ci-val" x="' . $x($n - 1) . '" y="' . ($y((int) $last['c']) - 9) . '" text-anchor="end">' . $esc($fmt($last['c'])) . '</text>';
		return $svg . '</svg>';
	}

	/**
	 * "Dimensions", "OpenAlex" or "Dimensions and OpenAlex", optionally linked.
	 */
	public static function sourcesLabel(array $sources, $html) {
		$names = array();
		foreach (array('dimensions', 'openalex') as $s) {
			if (!in_array($s, $sources, true)) {
				continue;
			}
			$name = $s === 'openalex' ? 'OpenAlex' : 'Dimensions';
			$url = $s === 'openalex' ? 'https://openalex.org/' : 'https://www.dimensions.ai/';
			$names[] = $html ? '<a href="' . $url . '" target="_blank" rel="noopener">' . $name . '</a>' : $name;
		}
		return implode(' ' . __('plugins.generic.citationImpact.and') . ' ', $names);
	}

	//
	// Drawing helpers
	//

	protected static function esc($s) {
		return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
	}

	/**
	 * Pick a step of the ramp for position $i of $n (0 = weakest).
	 * @return string CSS colour (a custom property set from the theme colour)
	 */
	protected static function rampAt($i, $n) {
		$steps = self::RAMP_STEPS;
		if ($n <= 1) {
			return 'var(--ci-r' . ($steps - 1) . ')';
		}
		return 'var(--ci-r' . (int) round($i / ($n - 1) * ($steps - 1)) . ')';
	}

	/**
	 * @param int $v
	 * @return int Axis maximum with four whole-number steps.
	 */
	protected static function niceMax($v) {
		$raw = max(1, (int) ceil($v / 4));
		$exp = pow(10, (int) floor(log10($raw)));
		foreach (array(1, 2, 5, 10) as $m) {
			if ($m * $exp >= $raw) {
				return (int) ($m * $exp * 4);
			}
		}
		return $raw * 4;
	}

	/**
	 * Donut showing the share of checked articles that have been cited.
	 * @param int $pct 0–100
	 * @return string SVG
	 */
	protected static function ring($pct) {
		$r = 26;
		$c = 2 * M_PI * $r;
		$on = round($c * max(0, min(100, $pct)) / 100, 2);
		return '<svg class="ci-ring" viewBox="0 0 64 64" aria-hidden="true">'
			. '<circle class="ci-ring-bg" cx="32" cy="32" r="' . $r . '" fill="none" stroke-width="8"/>'
			. '<circle class="ci-ring-fg" cx="32" cy="32" r="' . $r . '" fill="none" stroke-width="8" stroke-linecap="round"'
			. ' stroke-dasharray="' . $on . ' ' . round($c, 2) . '" transform="rotate(-90 32 32)"/>'
			. '<text x="32" y="36.5" text-anchor="middle" class="ci-ring-t">' . (int) $pct . '%</text></svg>';
	}

	/**
	 * Bars of citations by publication year. Bars run light → dark from the
	 * oldest to the newest year; the "last 3 years" window sits on a tinted band
	 * and its bars carry their values.
	 * @return string SVG
	 */
	protected static function yearChart(array $years, $fmt, $W, $variant) {
		if (!$years) {
			return '';
		}
		$narrow = $W < 500;
		$H = $narrow ? 230 : 270;
		$L = 44; $R = 8; $T = 34; $B = 28;
		$pw = $W - $L - $R;
		$ph = $H - $T - $B;
		$maxCites = 0;
		$maxIdx = 0;
		foreach (array_values($years) as $i => $y) {
			if ($y['citations'] > $maxCites) {
				$maxCites = $y['citations'];
				$maxIdx = $i;
			}
		}
		$max = self::niceMax(max(1, $maxCites));
		$n = count($years);
		$slot = $pw / $n;
		$bw = max(4, min(30, $slot * 0.62));
		$every = (int) ceil($n / ($narrow ? 6 : 14));
		$labelAll = !$narrow && $n <= 14;
		$wordCites = __('plugins.generic.citationImpact.chart.citations');
		$wordCite = __('plugins.generic.citationImpact.chart.citation');
		$wordArticles = __('plugins.generic.citationImpact.chart.articles');
		$esc = array(__CLASS__, 'esc');

		$svg = '<svg class="ci-chart ci-chart-' . $variant . '" viewBox="0 0 ' . $W . ' ' . $H . '" role="img" aria-label="' . $esc(__('plugins.generic.citationImpact.byYear')) . '">';

		// "Last 3 years" band behind the bars.
		$inWin = array();
		foreach (array_values($years) as $i => $y) {
			if (!empty($y['inWindow'])) {
				$inWin[] = $i;
			}
		}
		if ($inWin && count($inWin) < $n) {
			$x0 = round($L + $slot * min($inWin), 1);
			$x1 = round($L + $slot * (max($inWin) + 1), 1);
			$svg .= '<rect class="ci-band" x="' . $x0 . '" y="4" width="' . round($x1 - $x0, 1) . '" height="' . ($T + $ph - 4) . '" rx="6"/>';
			if (!$narrow) {
				$svg .= '<text class="ci-band-t" x="' . round(($x0 + $x1) / 2, 1) . '" y="17" text-anchor="middle">' . $esc(__('plugins.generic.citationImpact.chart.window')) . '</text>';
			}
		}

		for ($i = 0; $i <= 4; $i++) {
			$v = $max * $i / 4;
			$y = round($T + $ph - $ph * $i / 4, 1);
			$svg .= '<line class="ci-grid' . ($i === 0 ? ' ci-base' : '') . '" x1="' . $L . '" x2="' . ($W - $R) . '" y1="' . $y . '" y2="' . $y . '"/>';
			$svg .= '<text class="ci-tick" x="' . ($L - 8) . '" y="' . ($y + 4) . '" text-anchor="end">' . $esc($fmt($v)) . '</text>';
		}
		foreach (array_values($years) as $i => $yr) {
			$cx = $L + $slot * ($i + 0.5);
			$h = $yr['citations'] > 0 ? max(2, $ph * $yr['citations'] / $max) : 0;
			$x = round($cx - $bw / 2, 1);
			$y = round($T + $ph - $h, 1);
			$color = self::rampAt($i, $n);
			$tip = $yr['year'] . ' · ' . $fmt($yr['citations']) . ' ' . ($yr['citations'] == 1 ? $wordCite : $wordCites) . ' · ' . $fmt($yr['articles']) . ' ' . $wordArticles;
			$svg .= '<g class="ci-bar" tabindex="0" data-tip="' . $esc($tip) . '"><title>' . $esc($tip) . '</title>';
			$svg .= '<rect class="ci-hit" x="' . round($cx - $slot / 2, 1) . '" y="' . $T . '" width="' . round($slot, 1) . '" height="' . $ph . '"/>';
			if ($h > 0) {
				$r = min(4, $bw / 2, $h);
				$bwr = round($bw, 1);
				$hr = round($h, 1);
				$svg .= '<path class="ci-mark" style="fill:' . $color . '" d="M' . $x . ',' . ($y + $hr) . 'V' . ($y + $r) . 'Q' . $x . ',' . $y . ' ' . ($x + $r) . ',' . $y
					. 'H' . ($x + $bwr - $r) . 'Q' . ($x + $bwr) . ',' . $y . ' ' . ($x + $bwr) . ',' . ($y + $r) . 'V' . ($y + $hr) . 'Z"/>';
			}
			if ($yr['citations'] > 0 && ($labelAll || !empty($yr['inWindow']) || $i === $maxIdx)) {
				$svg .= '<text class="ci-val" x="' . round($cx, 1) . '" y="' . round($y - 6, 1) . '" text-anchor="middle">' . $esc($fmt($yr['citations'])) . '</text>';
			}
			$svg .= '</g>';
			// Anchor ticks to the newest year so it is always labelled.
			if (($n - 1 - $i) % $every === 0) {
				$svg .= '<text class="ci-tick' . (!empty($yr['inWindow']) ? ' ci-tick-w' : '') . '" x="' . round($cx, 1) . '" y="' . ($H - 8) . '" text-anchor="middle">' . (int) $yr['year'] . '</text>';
			}
		}
		return $svg . '</svg>';
	}

	/**
	 * Articles per citation band (0, 1–4, 5–9, 10–24, 25+), as HTML bars.
	 * @return array rows for the template
	 */
	protected static function distribution(array $bands, $checked, $fmt) {
		$out = array();
		$maxN = 0;
		foreach ($bands as $b) {
			$maxN = max($maxN, $b['articles']);
		}
		$colors = array('var(--ci-zero)', 'var(--ci-r0)', 'var(--ci-r3)', 'var(--ci-r6)', 'var(--ci-r8)');
		foreach ($bands as $i => $b) {
			if ($b['max'] === null) {
				$label = $b['min'] . '+';
			} elseif ($b['min'] === $b['max']) {
				$label = (string) $b['min'];
			} else {
				$label = $b['min'] . '–' . $b['max'];
			}
			$out[] = array(
				'label' => $label,
				'articles' => $fmt($b['articles']),
				'pct' => $checked ? round($b['articles'] / $checked * 100) : 0,
				'width' => $maxN ? round(max($b['articles'] ? 1.5 : 0, $b['articles'] / $maxN * 100), 1) : 0,
				'color' => isset($colors[$i]) ? $colors[$i] : 'var(--ci-r8)',
			);
		}
		return $out;
	}
}
